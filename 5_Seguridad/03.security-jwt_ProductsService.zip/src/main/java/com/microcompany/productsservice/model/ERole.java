package com.microcompany.productsservice.model;

public enum ERole {
    USER,
    ADMIN
}
